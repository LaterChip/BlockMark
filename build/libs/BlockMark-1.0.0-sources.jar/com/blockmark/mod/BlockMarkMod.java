package com.blockmark.mod;

import com.blockmark.mod.registry.ModBlocks;
import com.blockmark.mod.registry.ModItems;
import com.blockmark.mod.registry.ModBlockEntities;
import com.blockmark.mod.registry.ModScreenHandlers;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BlockMarkMod implements ModInitializer {
    public static final String MOD_ID = "blockmark";
    public static final Logger LOGGER = LoggerFactory.getLogger(BlockMarkMod.class);

    public static final class_5321<class_1761> BLOCKMARK_GROUP_KEY =
            class_5321.method_29179(class_7924.field_44688, id("blockmark_tab"));

    @Override
    public void onInitialize() {
        ModItems.register();
        ModBlocks.register();
        ModBlockEntities.register();
        ModScreenHandlers.register();

        class_2378.method_39197(class_7923.field_44687, BLOCKMARK_GROUP_KEY,
                FabricItemGroup.builder()
                        .method_47320(() -> new class_1799(ModItems.SUPERMARKET_LOGO))
                        .method_47321(class_2561.method_43471("itemGroup.blockmark.main"))
                        .method_47317((displayContext, entries) -> {
                            // Category 1: Fresh Produce
                            entries.method_45421(ModItems.BANANA);
                            entries.method_45421(ModItems.GRAPE);
                            entries.method_45421(ModItems.BLUEBERRY);
                            entries.method_45421(ModItems.STRAWBERRY);
                            entries.method_45421(ModItems.ORANGE);
                            entries.method_45421(ModItems.TOMATO);
                            entries.method_45421(ModItems.CUCUMBER);
                            entries.method_45421(ModItems.LETTUCE);
                            entries.method_45421(ModItems.CORN);
                            entries.method_45421(ModItems.GREEN_PEPPER);
                            entries.method_45421(ModItems.ONION);
                            entries.method_45421(ModItems.MUSHROOM_BOX);

                            // Category 2: Meat & Seafood
                            entries.method_45421(ModItems.BACON);
                            entries.method_45421(ModItems.SAUSAGE);
                            entries.method_45421(ModItems.SHRIMP);
                            entries.method_45421(ModItems.CRAB);
                            entries.method_45421(ModItems.FISH_FILLET);

                            // Category 3: Bakery
                            entries.method_45421(ModItems.TOAST);
                            entries.method_45421(ModItems.CROISSANT);
                            entries.method_45421(ModItems.DONUT);
                            entries.method_45421(ModItems.PIZZA);
                            entries.method_45421(ModItems.COOKIE_BOX);
                            entries.method_45421(ModItems.NOODLES);
                            entries.method_45421(ModItems.RICE);
                            entries.method_45421(ModItems.DUMPLING);

                            // Category 4: Snacks
                            entries.method_45421(ModItems.POTATO_CHIPS);
                            entries.method_45421(ModItems.CHOCOLATE);
                            entries.method_45421(ModItems.CANDY);
                            entries.method_45421(ModItems.POPCORN);
                            entries.method_45421(ModItems.NUTS);
                            entries.method_45421(ModItems.JELLY);
                            entries.method_45421(ModItems.WAFER);
                            entries.method_45421(ModItems.SPICY_STRIPS);
                            entries.method_45421(ModItems.CANNED_FRUIT);

                            // Category 5: Beverages
                            entries.method_45421(ModItems.BOTTLED_WATER);
                            entries.method_45421(ModItems.COLA);
                            entries.method_45421(ModItems.JUICE);
                            entries.method_45421(ModItems.MILK_TEA);
                            entries.method_45421(ModItems.COFFEE);
                            entries.method_45421(ModItems.BEER);
                            entries.method_45421(ModItems.YOGURT);
                            entries.method_45421(ModItems.ICE_CREAM);
                            entries.method_45421(ModItems.POPSICLE);

                            // Category 6: Groceries & Condiments
                            entries.method_45421(ModItems.FLOUR);
                            entries.method_45421(ModItems.COOKING_OIL);
                            entries.method_45421(ModItems.SALT);
                            entries.method_45421(ModItems.SAUCE);
                            entries.method_45421(ModItems.SOY_SAUCE);
                            entries.method_45421(ModItems.VINEGAR);
                            entries.method_45421(ModItems.BAGGED_RICE);

                            // Category 7: Daily Supplies
                            entries.method_45421(ModItems.TOWEL);
                            entries.method_45421(ModItems.SOAP);
                            entries.method_45421(ModItems.GARBAGE_BAG);
                            entries.method_45421(ModItems.FLASHLIGHT);
                            entries.method_45421(ModItems.STORAGE_BAG);
                            entries.method_45421(ModItems.CLEANER);

                            // Category 8: Garden Seeds
                            entries.method_45421(ModItems.SHRUB_SEEDS);
                            entries.method_45421(ModItems.POTTED_SEEDLING);
                            entries.method_45421(ModItems.FERTILIZER_BAG);

                            // Category 13: Clothing
                            entries.method_45421(ModItems.PET_COLLAR);
                            entries.method_45421(ModItems.PET_FOOD);

                            // Category 17: Seasonal
                            entries.method_45421(ModItems.GIFT_BOX);
                            entries.method_45421(ModItems.RIBBON);

                            // Category 12: Health
                            entries.method_45421(ModItems.FIRST_AID_KIT);
                            entries.method_45421(ModItems.BANDAGE);
                            entries.method_45421(ModItems.ENERGY_DRINK);

                            // Blocks - Shelves
                            entries.method_45421(ModBlocks.WALL_SHELF);
                            entries.method_45421(ModBlocks.DOUBLE_SIDED_SHELF);
                            entries.method_45421(ModBlocks.END_CAP_SHELF);
                            entries.method_45421(ModBlocks.WALL_MOUNT_SHELF);
                            entries.method_45421(ModBlocks.PRODUCE_DISPLAY);
                            entries.method_45421(ModBlocks.HEAVY_DUTY_SHELF);
                            entries.method_45421(ModBlocks.GLASS_CABINET);

                            // Blocks - Refrigeration
                            entries.method_45421(ModBlocks.BEVERAGE_COOLER);
                            entries.method_45421(ModBlocks.FREEZER_CHEST);
                            entries.method_45421(ModBlocks.FRIDGE);
                            entries.method_45421(ModBlocks.OPEN_COOLER);

                            // Blocks - Checkout
                            entries.method_45421(ModBlocks.CHECKOUT_COUNTER);
                            entries.method_45421(ModBlocks.BARCODE_SCANNER);
                            entries.method_45421(ModBlocks.SELF_CHECKOUT);
                            entries.method_45421(ModBlocks.PRICE_TAG);
                            entries.method_45421(ModBlocks.AD_SCREEN);

                            // Blocks - Facilities
                            entries.method_45421(ModBlocks.SHOPPING_BASKET);
                            entries.method_45421(ModBlocks.STORAGE_CRATE);
                            entries.method_45421(ModBlocks.PALLET);
                            entries.method_45421(ModBlocks.VENDING_MACHINE);
                            entries.method_45421(ModBlocks.TRASH_CAN);
                            entries.method_45421(ModBlocks.BENCH_TABLE);
                        })
                        .method_47324());
    }

    public static class_2960 id(String path) {
        return new class_2960(MOD_ID, path);
    }
}
