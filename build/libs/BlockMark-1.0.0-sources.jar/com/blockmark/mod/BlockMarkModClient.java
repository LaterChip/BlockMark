package com.blockmark.mod;

import com.blockmark.mod.registry.ModScreenHandlers;
import com.blockmark.mod.screen.*;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_3917;
import net.minecraft.class_3929;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Client-side initializer for the BlockMark mod.
 * <p>
 * Registers all screen handler types with their corresponding screen
 * implementations. This mapping enables Fabric's screen API to open
 * the correct GUI when a player interacts with a block.
 * </p>
 *
 * <h3>Registration Convention</h3>
 * Each {@code HandledScreens.register(...)} call binds a
 * {@link class_3917} to a screen constructor reference.
 * The constructor receives the screen handler and player inventory
 * as parameters.
 */
public class BlockMarkModClient implements ClientModInitializer {

    /**
     * Map of all registered screen handler types to their
     * screen implementation class names. Used for debugging
     * and inspection.
     */
    private static final Map<class_3917<?>, String> SCREEN_REGISTRY;

    static {
        Map<class_3917<?>, String> registry = new LinkedHashMap<>();
        registry.put(ModScreenHandlers.WALL_SHELF_SCREEN_HANDLER,
                WallShelfScreen.class.getSimpleName());
        registry.put(ModScreenHandlers.DOUBLE_SIDED_SHELF_SCREEN_HANDLER,
                DoubleSidedShelfScreen.class.getSimpleName());
        registry.put(ModScreenHandlers.END_CAP_SHELF_SCREEN_HANDLER,
                EndCapShelfScreen.class.getSimpleName());
        registry.put(ModScreenHandlers.HEAVY_DUTY_SHELF_SCREEN_HANDLER,
                HeavyDutyShelfScreen.class.getSimpleName());
        registry.put(ModScreenHandlers.BEVERAGE_COOLER_SCREEN_HANDLER,
                BeverageCoolerScreen.class.getSimpleName());
        registry.put(ModScreenHandlers.FREEZER_CHEST_SCREEN_HANDLER,
                FreezerChestScreen.class.getSimpleName());
        registry.put(ModScreenHandlers.FRIDGE_SCREEN_HANDLER,
                FridgeScreen.class.getSimpleName());
        registry.put(ModScreenHandlers.CHECKOUT_COUNTER_SCREEN_HANDLER,
                CheckoutCounterScreen.class.getSimpleName());
        registry.put(ModScreenHandlers.WALL_MOUNT_SHELF_SCREEN_HANDLER,
                WallMountShelfScreen.class.getSimpleName());
        registry.put(ModScreenHandlers.PRODUCE_DISPLAY_SCREEN_HANDLER,
                ProduceDisplayScreen.class.getSimpleName());
        registry.put(ModScreenHandlers.GLASS_CABINET_SCREEN_HANDLER,
                GlassCabinetScreen.class.getSimpleName());
        registry.put(ModScreenHandlers.OPEN_COOLER_SCREEN_HANDLER,
                OpenCoolerScreen.class.getSimpleName());
        registry.put(ModScreenHandlers.STORAGE_CRATE_SCREEN_HANDLER,
                StorageCrateScreen.class.getSimpleName());
        registry.put(ModScreenHandlers.VENDING_MACHINE_SCREEN_HANDLER,
                VendingMachineScreen.class.getSimpleName());
        SCREEN_REGISTRY = Collections.unmodifiableMap(registry);
    }

    /**
     * Initializes the client-side mod resources.
     * Called automatically by Fabric after all common initialization
     * has completed.
     */
    @Override
    public void onInitializeClient() {
        registerAllScreens();
        BlockMarkMod.LOGGER.info("BlockMark client initialized with {} screen types",
                SCREEN_REGISTRY.size());
    }

    /**
     * Registers all screen handler types with their corresponding
     * screen implementations via HandledScreens.
     */
    private void registerAllScreens() {
        class_3929.method_17542(ModScreenHandlers.WALL_SHELF_SCREEN_HANDLER,
                WallShelfScreen::new);
        class_3929.method_17542(ModScreenHandlers.DOUBLE_SIDED_SHELF_SCREEN_HANDLER,
                DoubleSidedShelfScreen::new);
        class_3929.method_17542(ModScreenHandlers.END_CAP_SHELF_SCREEN_HANDLER,
                EndCapShelfScreen::new);
        class_3929.method_17542(ModScreenHandlers.HEAVY_DUTY_SHELF_SCREEN_HANDLER,
                HeavyDutyShelfScreen::new);
        class_3929.method_17542(ModScreenHandlers.BEVERAGE_COOLER_SCREEN_HANDLER,
                BeverageCoolerScreen::new);
        class_3929.method_17542(ModScreenHandlers.FREEZER_CHEST_SCREEN_HANDLER,
                FreezerChestScreen::new);
        class_3929.method_17542(ModScreenHandlers.FRIDGE_SCREEN_HANDLER,
                FridgeScreen::new);
        class_3929.method_17542(ModScreenHandlers.CHECKOUT_COUNTER_SCREEN_HANDLER,
                CheckoutCounterScreen::new);
        class_3929.method_17542(ModScreenHandlers.WALL_MOUNT_SHELF_SCREEN_HANDLER,
                WallMountShelfScreen::new);
        class_3929.method_17542(ModScreenHandlers.PRODUCE_DISPLAY_SCREEN_HANDLER,
                ProduceDisplayScreen::new);
        class_3929.method_17542(ModScreenHandlers.GLASS_CABINET_SCREEN_HANDLER,
                GlassCabinetScreen::new);
        class_3929.method_17542(ModScreenHandlers.OPEN_COOLER_SCREEN_HANDLER,
                OpenCoolerScreen::new);
        class_3929.method_17542(ModScreenHandlers.STORAGE_CRATE_SCREEN_HANDLER,
                StorageCrateScreen::new);
        class_3929.method_17542(ModScreenHandlers.VENDING_MACHINE_SCREEN_HANDLER,
                VendingMachineScreen::new);
    }

    /**
     * Returns a read-only view of the registered screen handler-to-screen
     * class mapping.
     *
     * @return an unmodifiable map of handler types to screen class names
     */
    public static Map<class_3917<?>, String> getScreenRegistry() {
        return SCREEN_REGISTRY;
    }

    /**
     * Returns the total number of screen types registered.
     *
     * @return the screen type count
     */
    public static int getScreenCount() {
        return SCREEN_REGISTRY.size();
    }
}
