package com.blockmark.mod.registry;

import com.blockmark.mod.BlockMarkMod;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public class ModItems {
    // Logo item
    public static final class_1792 SUPERMARKET_LOGO = register("supermarket_logo", new class_1792(new class_1792.class_1793()));

    // BlockItems
    public static final class_1792 WALL_SHELF = registerBlockItem(ModBlocks.WALL_SHELF);
    public static final class_1792 DOUBLE_SIDED_SHELF = registerBlockItem(ModBlocks.DOUBLE_SIDED_SHELF);
    public static final class_1792 END_CAP_SHELF = registerBlockItem(ModBlocks.END_CAP_SHELF);
    public static final class_1792 WALL_MOUNT_SHELF = registerBlockItem(ModBlocks.WALL_MOUNT_SHELF);
    public static final class_1792 PRODUCE_DISPLAY = registerBlockItem(ModBlocks.PRODUCE_DISPLAY);
    public static final class_1792 HEAVY_DUTY_SHELF = registerBlockItem(ModBlocks.HEAVY_DUTY_SHELF);
    public static final class_1792 GLASS_CABINET = registerBlockItem(ModBlocks.GLASS_CABINET);
    public static final class_1792 BEVERAGE_COOLER = registerBlockItem(ModBlocks.BEVERAGE_COOLER);
    public static final class_1792 FREEZER_CHEST = registerBlockItem(ModBlocks.FREEZER_CHEST);
    public static final class_1792 FRIDGE = registerBlockItem(ModBlocks.FRIDGE);
    public static final class_1792 OPEN_COOLER = registerBlockItem(ModBlocks.OPEN_COOLER);
    public static final class_1792 CHECKOUT_COUNTER = registerBlockItem(ModBlocks.CHECKOUT_COUNTER);
    public static final class_1792 BARCODE_SCANNER = registerBlockItem(ModBlocks.BARCODE_SCANNER);
    public static final class_1792 SELF_CHECKOUT = registerBlockItem(ModBlocks.SELF_CHECKOUT);
    public static final class_1792 PRICE_TAG = registerBlockItem(ModBlocks.PRICE_TAG);
    public static final class_1792 AD_SCREEN = registerBlockItem(ModBlocks.AD_SCREEN);
    public static final class_1792 SHOPPING_BASKET_BLOCK = registerBlockItem(ModBlocks.SHOPPING_BASKET);
    public static final class_1792 STORAGE_CRATE = registerBlockItem(ModBlocks.STORAGE_CRATE);
    public static final class_1792 PALLET = registerBlockItem(ModBlocks.PALLET);
    public static final class_1792 VENDING_MACHINE = registerBlockItem(ModBlocks.VENDING_MACHINE);
    public static final class_1792 TRASH_CAN = registerBlockItem(ModBlocks.TRASH_CAN);
    public static final class_1792 BENCH_TABLE = registerBlockItem(ModBlocks.BENCH_TABLE);

    // Category 1: Fresh Produce (12 items)
    public static final class_1792 BANANA = registerFood("banana", 4, 3.0f);
    public static final class_1792 GRAPE = registerFood("grape", 2, 1.5f);
    public static final class_1792 BLUEBERRY = registerFood("blueberry", 2, 1.0f);
    public static final class_1792 STRAWBERRY = registerFood("strawberry", 3, 2.0f);
    public static final class_1792 ORANGE = registerFood("orange", 4, 3.5f);
    public static final class_1792 TOMATO = registerFood("tomato", 3, 2.5f);
    public static final class_1792 CUCUMBER = registerFood("cucumber", 2, 2.0f);
    public static final class_1792 LETTUCE = registerFood("lettuce", 2, 1.5f);
    public static final class_1792 CORN = registerFood("corn", 3, 3.0f);
    public static final class_1792 GREEN_PEPPER = registerFood("green_pepper", 3, 2.0f);
    public static final class_1792 ONION = registerFood("onion", 2, 1.5f);
    public static final class_1792 MUSHROOM_BOX = registerFood("mushroom_box", 5, 4.0f);

    // Category 2: Meat & Seafood (5 items)
    public static final class_1792 BACON = registerFood("bacon", 4, 5.0f);
    public static final class_1792 SAUSAGE = registerFood("sausage", 5, 5.5f);
    public static final class_1792 SHRIMP = registerFood("shrimp", 3, 3.5f);
    public static final class_1792 CRAB = registerFood("crab", 5, 6.0f);
    public static final class_1792 FISH_FILLET = registerFood("fish_fillet", 4, 4.5f);

    // Category 3: Bakery (8 items)
    public static final class_1792 TOAST = registerFood("toast", 5, 6.0f);
    public static final class_1792 CROISSANT = registerFood("croissant", 5, 6.5f);
    public static final class_1792 DONUT = registerFood("donut", 4, 5.0f);
    public static final class_1792 PIZZA = registerFood("pizza", 8, 10.0f);
    public static final class_1792 COOKIE_BOX = registerFood("cookie_box", 6, 4.0f);
    public static final class_1792 NOODLES = registerFood("noodles", 5, 6.0f);
    public static final class_1792 RICE = registerFood("rice", 6, 7.0f);
    public static final class_1792 DUMPLING = registerFood("dumpling", 6, 7.5f);

    // Category 4: Snacks (9 items)
    public static final class_1792 POTATO_CHIPS = registerFood("potato_chips", 3, 3.0f);
    public static final class_1792 CHOCOLATE = registerFood("chocolate", 4, 4.5f);
    public static final class_1792 CANDY = registerFood("candy", 2, 2.0f);
    public static final class_1792 POPCORN = registerFood("popcorn", 3, 2.5f);
    public static final class_1792 NUTS = registerFood("nuts", 3, 3.5f);
    public static final class_1792 JELLY = registerFood("jelly", 2, 2.0f);
    public static final class_1792 WAFER = registerFood("wafer", 3, 3.0f);
    public static final class_1792 SPICY_STRIPS = registerFood("spicy_strips", 2, 2.5f);
    public static final class_1792 CANNED_FRUIT = registerFood("canned_fruit", 4, 4.0f);

    // Category 5: Beverages (9 items)
    public static final class_1792 BOTTLED_WATER = registerDrink("bottled_water", 1, 1.0f);
    public static final class_1792 COLA = registerDrink("cola", 3, 2.5f);
    public static final class_1792 JUICE = registerDrink("juice", 4, 3.0f);
    public static final class_1792 MILK_TEA = registerDrink("milk_tea", 5, 4.0f);
    public static final class_1792 COFFEE = registerDrink("coffee", 4, 3.5f);
    public static final class_1792 BEER = registerDrink("beer", 3, 2.0f);
    public static final class_1792 YOGURT = registerFood("yogurt", 4, 3.5f);
    public static final class_1792 ICE_CREAM = registerFood("ice_cream", 4, 3.0f);
    public static final class_1792 POPSICLE = registerFood("popsicle", 3, 2.0f);

    // Category 6: Groceries & Condiments (7 items)
    public static final class_1792 FLOUR = register("flour", new class_1792(new class_1792.class_1793()));
    public static final class_1792 COOKING_OIL = register("cooking_oil", new class_1792(new class_1792.class_1793()));
    public static final class_1792 SALT = register("salt", new class_1792(new class_1792.class_1793()));
    public static final class_1792 SAUCE = register("sauce", new class_1792(new class_1792.class_1793()));
    public static final class_1792 SOY_SAUCE = register("soy_sauce", new class_1792(new class_1792.class_1793()));
    public static final class_1792 VINEGAR = register("vinegar", new class_1792(new class_1792.class_1793()));
    public static final class_1792 BAGGED_RICE = register("bagged_rice", new class_1792(new class_1792.class_1793()));

    // Category 7: Daily Supplies (6 items)
    public static final class_1792 TOWEL = register("towel", new class_1792(new class_1792.class_1793()));
    public static final class_1792 SOAP = register("soap", new class_1792(new class_1792.class_1793()));
    public static final class_1792 GARBAGE_BAG = register("garbage_bag", new class_1792(new class_1792.class_1793()));
    public static final class_1792 FLASHLIGHT = register("flashlight", new class_1792(new class_1792.class_1793()));
    public static final class_1792 STORAGE_BAG = register("storage_bag", new class_1792(new class_1792.class_1793()));
    public static final class_1792 CLEANER = register("cleaner", new class_1792(new class_1792.class_1793()));

    // Category 8: Garden (3 items)
    public static final class_1792 SHRUB_SEEDS = register("shrub_seeds", new class_1792(new class_1792.class_1793()));
    public static final class_1792 POTTED_SEEDLING = register("potted_seedling", new class_1792(new class_1792.class_1793()));
    public static final class_1792 FERTILIZER_BAG = register("fertilizer_bag", new class_1792(new class_1792.class_1793()));

    // Category 12: Health (3 items)
    public static final class_1792 FIRST_AID_KIT = register("first_aid_kit", new class_1792(new class_1792.class_1793()));
    public static final class_1792 BANDAGE = register("bandage", new class_1792(new class_1792.class_1793()));
    public static final class_1792 ENERGY_DRINK = registerDrink("energy_drink", 3, 3.0f);

    // Category 15: Pet (2 items)
    public static final class_1792 PET_COLLAR = register("pet_collar", new class_1792(new class_1792.class_1793()));
    public static final class_1792 PET_FOOD = register("pet_food", new class_1792(new class_1792.class_1793()));

    // Category 17: Seasonal (2 items)
    public static final class_1792 GIFT_BOX = register("gift_box", new class_1792(new class_1792.class_1793()));
    public static final class_1792 RIBBON = register("ribbon", new class_1792(new class_1792.class_1793()));

    private static class_1792 register(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, BlockMarkMod.id(name), item);
    }

    private static class_1792 registerFood(String name, int hunger, float saturation) {
        return class_2378.method_10230(class_7923.field_41178, BlockMarkMod.id(name),
                new class_1792(new class_1792.class_1793().method_19265(new net.minecraft.class_4174.class_4175()
                        .method_19238(hunger).method_19237(saturation).method_19242())));
    }

    private static class_1792 registerDrink(String name, int hunger, float saturation) {
        return class_2378.method_10230(class_7923.field_41178, BlockMarkMod.id(name),
                new class_1792(new class_1792.class_1793().method_19265(new net.minecraft.class_4174.class_4175()
                        .method_19238(hunger).method_19237(saturation).method_19242())
                        .method_7889(16)));
    }

    public static void register() {
    }

    private static class_1792 registerBlockItem(net.minecraft.class_2248 block) {
        return class_2378.method_10230(class_7923.field_41178, class_7923.field_41175.method_10221(block),
                new class_1747(block, new class_1792.class_1793()));
    }
}
