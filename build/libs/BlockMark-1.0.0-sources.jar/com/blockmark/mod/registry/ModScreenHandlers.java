package com.blockmark.mod.registry;

import com.blockmark.mod.BlockMarkMod;
import com.blockmark.mod.screen.CheckoutCounterScreenHandler;
import com.blockmark.mod.screen.WallShelfScreenHandler;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2378;
import net.minecraft.class_3917;
import net.minecraft.class_7701;
import net.minecraft.class_7923;

/**
 * Registry for all screen handler types in the BlockMark mod.
 * <p>
 * Each shelf/cooler/display block gets its own screen handler type to allow
 * for separate GUI handling. The checkout counter has its own 27-slot handler.
 * This class provides utility methods for querying and grouping handler types.
 * </p>
 *
 * <h3>Handler Groups</h3>
 * <ul>
 *   <li><b>Shelf handlers:</b> Use WallShelfScreenHandler (14 types)</li>
 *   <li><b>Checkout handler:</b> Uses CheckoutCounterScreenHandler (1 type)</li>
 * </ul>
 */
public class ModScreenHandlers {

    // --- Shelf / Display handlers (WallShelfScreenHandler) ---

    public static final class_3917<WallShelfScreenHandler> WALL_SHELF_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, BlockMarkMod.id("wall_shelf"),
                    new class_3917<>(WallShelfScreenHandler::new, class_7701.field_40182));

    public static final class_3917<WallShelfScreenHandler> DOUBLE_SIDED_SHELF_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, BlockMarkMod.id("double_sided_shelf"),
                    new class_3917<>(WallShelfScreenHandler::new, class_7701.field_40182));

    public static final class_3917<WallShelfScreenHandler> END_CAP_SHELF_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, BlockMarkMod.id("end_cap_shelf"),
                    new class_3917<>(WallShelfScreenHandler::new, class_7701.field_40182));

    public static final class_3917<WallShelfScreenHandler> HEAVY_DUTY_SHELF_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, BlockMarkMod.id("heavy_duty_shelf"),
                    new class_3917<>(WallShelfScreenHandler::new, class_7701.field_40182));

    public static final class_3917<WallShelfScreenHandler> BEVERAGE_COOLER_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, BlockMarkMod.id("beverage_cooler"),
                    new class_3917<>(WallShelfScreenHandler::new, class_7701.field_40182));

    public static final class_3917<WallShelfScreenHandler> FREEZER_CHEST_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, BlockMarkMod.id("freezer_chest"),
                    new class_3917<>(WallShelfScreenHandler::new, class_7701.field_40182));

    public static final class_3917<WallShelfScreenHandler> FRIDGE_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, BlockMarkMod.id("fridge"),
                    new class_3917<>(WallShelfScreenHandler::new, class_7701.field_40182));

    public static final class_3917<CheckoutCounterScreenHandler> CHECKOUT_COUNTER_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, BlockMarkMod.id("checkout_counter"),
                    new class_3917<>(CheckoutCounterScreenHandler::new, class_7701.field_40182));

    public static final class_3917<WallShelfScreenHandler> WALL_MOUNT_SHELF_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, BlockMarkMod.id("wall_mount_shelf"),
                    new class_3917<>(WallShelfScreenHandler::new, class_7701.field_40182));

    public static final class_3917<WallShelfScreenHandler> PRODUCE_DISPLAY_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, BlockMarkMod.id("produce_display"),
                    new class_3917<>(WallShelfScreenHandler::new, class_7701.field_40182));

    public static final class_3917<WallShelfScreenHandler> GLASS_CABINET_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, BlockMarkMod.id("glass_cabinet"),
                    new class_3917<>(WallShelfScreenHandler::new, class_7701.field_40182));

    public static final class_3917<WallShelfScreenHandler> OPEN_COOLER_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, BlockMarkMod.id("open_cooler"),
                    new class_3917<>(WallShelfScreenHandler::new, class_7701.field_40182));

    public static final class_3917<WallShelfScreenHandler> STORAGE_CRATE_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, BlockMarkMod.id("storage_crate"),
                    new class_3917<>(WallShelfScreenHandler::new, class_7701.field_40182));

    public static final class_3917<WallShelfScreenHandler> VENDING_MACHINE_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, BlockMarkMod.id("vending_machine"),
                    new class_3917<>(WallShelfScreenHandler::new, class_7701.field_40182));

    /**
     * Returns all registered screen handler types in a read-only map.
     * Keys are the registration IDs, values are the type instances.
     *
     * @return an unmodifiable map of all handler types
     */
    public static Map<String, class_3917<?>> getAllTypes() {
        Map<String, class_3917<?>> map = new LinkedHashMap<>();
        map.put("wall_shelf", WALL_SHELF_SCREEN_HANDLER);
        map.put("double_sided_shelf", DOUBLE_SIDED_SHELF_SCREEN_HANDLER);
        map.put("end_cap_shelf", END_CAP_SHELF_SCREEN_HANDLER);
        map.put("heavy_duty_shelf", HEAVY_DUTY_SHELF_SCREEN_HANDLER);
        map.put("beverage_cooler", BEVERAGE_COOLER_SCREEN_HANDLER);
        map.put("freezer_chest", FREEZER_CHEST_SCREEN_HANDLER);
        map.put("fridge", FRIDGE_SCREEN_HANDLER);
        map.put("checkout_counter", CHECKOUT_COUNTER_SCREEN_HANDLER);
        map.put("wall_mount_shelf", WALL_MOUNT_SHELF_SCREEN_HANDLER);
        map.put("produce_display", PRODUCE_DISPLAY_SCREEN_HANDLER);
        map.put("glass_cabinet", GLASS_CABINET_SCREEN_HANDLER);
        map.put("open_cooler", OPEN_COOLER_SCREEN_HANDLER);
        map.put("storage_crate", STORAGE_CRATE_SCREEN_HANDLER);
        map.put("vending_machine", VENDING_MACHINE_SCREEN_HANDLER);
        return Collections.unmodifiableMap(map);
    }

    /**
     * Returns the total number of registered screen handler types.
     *
     * @return the count of registered handler types
     */
    public static int getHandlerCount() {
        return getAllTypes().size();
    }

    /**
     * Called during mod initialization to trigger static class loading
     * and ensure all screen handler types are registered.
     */
    public static void register() {
        // Static fields are initialized on class load; this method exists
        // as an explicit registration entry point called by BlockMarkMod
    }
}
