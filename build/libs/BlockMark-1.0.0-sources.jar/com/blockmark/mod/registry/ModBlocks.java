package com.blockmark.mod.registry;

import com.blockmark.mod.BlockMarkMod;
import com.blockmark.mod.block.*;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

/**
 * Central registry for all custom blocks in the BlockMark mod.
 * <p>
 * Blocks are organized into functional categories:
 * <ul>
 *   <li><b>Shelving:</b> WallShelf, DoubleSidedShelf, EndCapShelf, WallMountShelf,
 *       HeavyDutyShelf, GlassCabinet, ProduceDisplay</li>
 *   <li><b>Refrigeration:</b> BeverageCooler, FreezerChest, Fridge, OpenCooler</li>
 *   <li><b>Checkout:</b> CheckoutCounter, BarcodeScanner, SelfCheckout, PriceTag, AdScreen</li>
 *   <li><b>Facilities:</b> ShoppingBasket, StorageCrate, Pallet, VendingMachine,
 *       TrashCan, BenchTable</li>
 * </ul>
 * Each block is registered with {@link class_2378#BLOCK} using a namespaced ID.
 */
public class ModBlocks {
    // Shelving - Wall Shelf (27 slots, single-sided)
    public static final class_2248 WALL_SHELF = register("wall_shelf",
            new WallShelfBlock(FabricBlockSettings.copyOf(class_2246.field_10161).method_22488()));

    // Shelving - Double Sided Shelf (36 slots, accessible from both sides)
    public static final class_2248 DOUBLE_SIDED_SHELF = register("double_sided_shelf",
            new DoubleSidedShelfBlock(FabricBlockSettings.copyOf(class_2246.field_10161).method_22488()));

    // Shelving - End Cap Shelf (promo, lower height)
    public static final class_2248 END_CAP_SHELF = register("end_cap_shelf",
            new EndCapShelfBlock(FabricBlockSettings.copyOf(class_2246.field_10161).method_22488()));

    // Shelving - Wall Mount Shelf (wall-mounted, 9 slots)
    public static final class_2248 WALL_MOUNT_SHELF = register("wall_mount_shelf",
            new WallMountShelfBlock(FabricBlockSettings.copyOf(class_2246.field_10161).method_22488()));

    // Produce Display (open display for fruits/vegetables, 18 slots)
    public static final class_2248 PRODUCE_DISPLAY = register("produce_display",
            new ProduceDisplayBlock(FabricBlockSettings.copyOf(class_2246.field_10161).method_22488()));

    // Heavy Duty Shelf (metal, large capacity, 54 slots)
    public static final class_2248 HEAVY_DUTY_SHELF = register("heavy_duty_shelf",
            new HeavyDutyShelfBlock(FabricBlockSettings.copyOf(class_2246.field_10085).method_22488()));

    // Glass Cabinet (potion/rare items, 27 slots, glass front)
    public static final class_2248 GLASS_CABINET = register("glass_cabinet",
            new GlassCabinetBlock(FabricBlockSettings.copyOf(class_2246.field_10033).method_22488().method_9631(s -> 3)));

    // Refrigeration - Beverage Cooler (glass door, lit, 18 slots)
    public static final class_2248 BEVERAGE_COOLER = register("beverage_cooler",
            new BeverageCoolerBlock(FabricBlockSettings.copyOf(class_2246.field_10085).method_22488().method_9631(s -> 12)));

    // Refrigeration - Freezer Chest (chest-style, 27 slots)
    public static final class_2248 FREEZER_CHEST = register("freezer_chest",
            new FreezerChestBlock(FabricBlockSettings.copyOf(class_2246.field_10085).method_22488()));

    // Refrigeration - Fridge (double door, 54 slots)
    public static final class_2248 FRIDGE = register("fridge",
            new FridgeBlock(FabricBlockSettings.copyOf(class_2246.field_10085).method_22488().method_9631(s -> 8)));

    // Refrigeration - Open Cooler (no glass, 18 slots)
    public static final class_2248 OPEN_COOLER = register("open_cooler",
            new OpenCoolerBlock(FabricBlockSettings.copyOf(class_2246.field_10085).method_22488()));

    // Checkout - Counter (main GUI for shopping, 27 slots)
    public static final class_2248 CHECKOUT_COUNTER = register("checkout_counter",
            new CheckoutCounterBlock(FabricBlockSettings.copyOf(class_2246.field_10161).method_22488()));

    // Checkout - Barcode Scanner (decorative + interactive)
    public static final class_2248 BARCODE_SCANNER = register("barcode_scanner",
            new class_2248(FabricBlockSettings.copyOf(class_2246.field_10085).method_22488()));

    // Checkout - Self Checkout
    public static final class_2248 SELF_CHECKOUT = register("self_checkout",
            new class_2248(FabricBlockSettings.copyOf(class_2246.field_10085).method_22488()));

    // Checkout - Price Tag (text display stand)
    public static final class_2248 PRICE_TAG = register("price_tag",
            new PriceTagBlock(FabricBlockSettings.copyOf(class_2246.field_10161).method_22488()));

    // Checkout - Ad Screen
    public static final class_2248 AD_SCREEN = register("ad_screen",
            new class_2248(FabricBlockSettings.copyOf(class_2246.field_10085).method_22488().method_9631(s -> 10)));

    // Facilities - Shopping Basket (placeable)
    public static final class_2248 SHOPPING_BASKET = register("shopping_basket",
            new class_2248(FabricBlockSettings.copyOf(class_2246.field_10161).method_22488()));

    // Facilities - Storage Crate (small storage, 9 slots)
    public static final class_2248 STORAGE_CRATE = register("storage_crate",
            new StorageCrateBlock(FabricBlockSettings.copyOf(class_2246.field_10161).method_22488()));

    // Facilities - Pallet
    public static final class_2248 PALLET = register("pallet",
            new class_2248(FabricBlockSettings.copyOf(class_2246.field_10161).method_22488()));

    // Facilities - Vending Machine
    public static final class_2248 VENDING_MACHINE = register("vending_machine",
            new VendingMachineBlock(FabricBlockSettings.copyOf(class_2246.field_10085).method_22488().method_9631(s -> 8)));

    // Facilities - Trash Can
    public static final class_2248 TRASH_CAN = register("trash_can",
            new class_2248(FabricBlockSettings.copyOf(class_2246.field_10085).method_22488()));

    // Facilities - Bench Table
    public static final class_2248 BENCH_TABLE = register("bench_table",
            new class_2248(FabricBlockSettings.copyOf(class_2246.field_10161).method_22488()));

    private static class_2248 register(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, BlockMarkMod.id(name), block);
    }

    /**
     * Returns a list of all registered blocks for iteration or bulk operations.
     *
     * @return an unmodifiable list of all registered Block instances
     */
    public static java.util.List<class_2248> getAllBlocks() {
        return java.util.List.of(
                WALL_SHELF, DOUBLE_SIDED_SHELF, END_CAP_SHELF, WALL_MOUNT_SHELF,
                PRODUCE_DISPLAY, HEAVY_DUTY_SHELF, GLASS_CABINET,
                BEVERAGE_COOLER, FREEZER_CHEST, FRIDGE, OPEN_COOLER,
                CHECKOUT_COUNTER, BARCODE_SCANNER, SELF_CHECKOUT, PRICE_TAG, AD_SCREEN,
                SHOPPING_BASKET, STORAGE_CRATE, PALLET, VENDING_MACHINE,
                TRASH_CAN, BENCH_TABLE
        );
    }

    /**
     * Returns the total number of registered blocks.
     *
     * @return the block count
     */
    public static int getBlockCount() {
        return getAllBlocks().size();
    }

    /**
     * Returns all blocks that implement a specific type (e.g., BlockWithEntity).
     * Useful for programmatic iteration over shelf-like blocks.
     *
     * @param clazz  the class to filter by
     * @param <T>    the block type
     * @return a list of blocks assignable to the given class
     */
    @SuppressWarnings("unchecked")
    public static <T extends class_2248> java.util.List<T> getBlocksOfType(Class<T> clazz) {
        return getAllBlocks().stream()
                .filter(clazz::isInstance)
                .map(b -> (T) b)
                .collect(java.util.stream.Collectors.toList());
    }

    public static void register() {
    }
}
