package com.blockmark.mod.screen;

import com.blockmark.mod.BlockMarkMod;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.lwjgl.glfw.GLFW;

/**
 * Handled screen for the Wall Mount Shelf block - a compact wall-mounted
 * shelf with 9 slots. Features keyboard hotbar shortcuts, shift-scroll
 * quick-move, and standard ESC / inventory key close.
 */
public class WallMountShelfScreen extends class_465<WallShelfScreenHandler> {
    private static final class_2960 TEXTURE = BlockMarkMod.id("textures/gui/wall_mount_shelf.png");
    private static final int INVENTORY_ROWS = 3;
    private static final int INVENTORY_COLS = 9;

    public WallMountShelfScreen(WallShelfScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        this.field_2779 = 166;
        this.field_25270 = this.field_2779 - 93;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.field_25267 = (this.field_2792 - this.field_22793.method_27525(this.field_22785)) / 2;
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;
        context.method_25302(TEXTURE, x, y, 0, 0, field_2792, field_2779);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        context.method_51439(this.field_22793, this.field_22785, this.field_25267, this.field_25268, 0x404040, false);
        context.method_51439(this.field_22793, this.field_29347, this.field_25269,
                this.field_25270, 0x404040, false);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);
        method_2380(context, mouseX, mouseY);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || this.field_22787.field_1724.method_21823()) {
            this.method_25419();
            return true;
        }
        if (this.field_22787.field_1690.field_1822.method_1417(keyCode, scanCode)) {
            this.method_25419();
            return true;
        }
        int hotbarSlot = mapKeyToHotbarSlot(keyCode);
        if (hotbarSlot >= 0 && hotbarSlot <= 8) {
            if (this.field_2797.method_34255().method_7960()) {
                handleHotbarKeyPress(hotbarSlot);
            }
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private static int mapKeyToHotbarSlot(int keyCode) {
        if (keyCode >= GLFW.GLFW_KEY_1 && keyCode <= GLFW.GLFW_KEY_9) {
            return keyCode - GLFW.GLFW_KEY_1;
        }
        if (keyCode == GLFW.GLFW_KEY_0) {
            return 8;
        }
        return -1;
    }

    private void handleHotbarKeyPress(int hotbarSlot) {
        if (this.field_2787 != null && this.field_2787.method_7681()) {
            int containerSlots = ((WallShelfScreenHandler) this.field_2797).getInventory().method_5439();
            int targetSlot = containerSlots + INVENTORY_ROWS * INVENTORY_COLS + hotbarSlot;
            if (targetSlot < this.field_2797.field_7761.size()) {
                this.method_2383(this.field_2787, this.field_2787.field_7874, hotbarSlot,
                        net.minecraft.class_1713.field_7791);
            }
        }
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (this.field_2787 != null && this.field_2787.method_7681() && method_25442()) {
            int direction = verticalAmount > 0 ? 1 : -1;
            int newSlotId = this.field_2787.field_7874 + direction;
            int containerSize = ((WallShelfScreenHandler) this.field_2797).getInventory().method_5439();
            if (newSlotId >= 0 && newSlotId < containerSize) {
                this.method_2383(this.field_2787, this.field_2787.field_7874, 0,
                        net.minecraft.class_1713.field_7794);
            }
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    protected void method_2380(class_332 context, int x, int y) {
        super.method_2380(context, x, y);
    }
}
