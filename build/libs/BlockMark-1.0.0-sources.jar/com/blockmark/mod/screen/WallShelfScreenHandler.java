package com.blockmark.mod.screen;

import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3917;

/**
 * Screen handler shared by all shelf, cooler, display, and vending machine blocks.
 * <p>
 * Provides a 9x3 grid (27 slots) for block inventory plus the standard
 * player inventory (3 rows main + 1 row hotbar). Supports shift-click
 * quick transfer between inventory areas.
 * </p>
 *
 * <h3>Slot Layout</h3>
 * <ul>
 *   <li>Slots 0-26:  Block inventory (9 columns x 3 rows, y=18)</li>
 *   <li>Slots 27-53: Player main inventory (9 columns x 3 rows, y=84)</li>
 *   <li>Slots 54-62: Player hotbar (9 columns, y=142)</li>
 * </ul>
 */
public class WallShelfScreenHandler extends class_1703 {
    private final class_1263 inventory;

    /**
     * Client-side fallback constructor with a temporary SimpleInventory.
     *
     * @param syncId          the synchronization ID
     * @param playerInventory the player's inventory
     */
    public WallShelfScreenHandler(int syncId, class_1661 playerInventory) {
        this(syncId, playerInventory, new class_1277(27));
    }

    /**
     * Server-side constructor without explicit type.
     *
     * @param syncId          the synchronization ID
     * @param playerInventory the player's inventory
     * @param inventory       the block entity's inventory (27 slots)
     */
    public WallShelfScreenHandler(int syncId, class_1661 playerInventory, class_1263 inventory) {
        super(null, syncId);
        this.inventory = inventory;
        method_17359(inventory, 27);
        inventory.method_5435(playerInventory.field_7546);
        buildSlots(playerInventory);
    }

    /**
     * Full constructor with explicit screen handler type.
     *
     * @param type            the registered screen handler type
     * @param syncId          the synchronization ID
     * @param playerInventory the player's inventory
     * @param inventory       the block entity's inventory (27 slots)
     */
    public WallShelfScreenHandler(class_3917<?> type, int syncId, class_1661 playerInventory, class_1263 inventory) {
        super(type, syncId);
        this.inventory = inventory;
        method_17359(inventory, 27);
        inventory.method_5435(playerInventory.field_7546);
        buildSlots(playerInventory);
    }

    /**
     * Builds all slot components for the screen handler layout.
     * Includes block inventory (3x9), player inventory (3x9), and hotbar (9).
     *
     * @param playerInventory the player's inventory reference
     */
    private void buildSlots(class_1661 playerInventory) {
        // Block inventory: 3 rows of 9
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.method_7621(new class_1735(inventory, col + row * 9, 8 + col * 18, 18 + row * 18));
            }
        }

        // Player inventory: 3 rows of 9
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.method_7621(new class_1735(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }

        // Hotbar: 1 row of 9
        for (int col = 0; col < 9; col++) {
            this.method_7621(new class_1735(playerInventory, col, 8 + col * 18, 142));
        }
    }

    @Override
    public class_1799 method_7601(class_1657 player, int invSlot) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(invSlot);
        if (slot != null && slot.method_7681()) {
            class_1799 originalStack = slot.method_7677();
            newStack = originalStack.method_7972();
            if (invSlot < this.inventory.method_5439()) {
                if (!this.method_7616(originalStack, this.inventory.method_5439(), this.field_7761.size(), true)) {
                    return class_1799.field_8037;
                }
            } else {
                if (!this.method_7616(originalStack, 0, this.inventory.method_5439(), false)) {
                    return class_1799.field_8037;
                }
            }
            if (originalStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }
        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return this.inventory.method_5443(player);
    }

    /**
     * Returns the backing inventory instance for this screen handler.
     *
     * @return the block entity inventory
     */
    public class_1263 getInventory() {
        return inventory;
    }
}
