package com.blockmark.mod.block.entity;

import com.blockmark.mod.registry.ModBlockEntities;
import com.blockmark.mod.registry.ModScreenHandlers;
import com.blockmark.mod.screen.CheckoutCounterScreenHandler;
import net.minecraft.class_1262;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3908;

/**
 * Block entity for the Checkout Counter block.
 * <p>
 * Manages a 27-slot inventory with standard NBT persistence.
 * Implements both NamedScreenHandlerFactory and Inventory so the
 * block can be opened via right-click and retain items across
 * chunk loads. Also provides comparator output for redstone
 * integration.
 * </p>
 */
public class CheckoutCounterBlockEntity extends class_2586
        implements class_3908, net.minecraft.class_1263 {

    private final class_2371<class_1799> inventory = class_2371.method_10213(27, class_1799.field_8037);

    /**
     * Constructs a new CheckoutCounterBlockEntity.
     *
     * @param pos   the block position in the world
     * @param state the current block state
     */
    public CheckoutCounterBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.CHECKOUT_COUNTER_ENTITY, pos, state);
    }

    /**
     * Creates the screen handler for this block entity.
     *
     * @param syncId          the synchronization ID
     * @param playerInventory the player's inventory
     * @param player          the player opening the screen
     * @return a new CheckoutCounterScreenHandler
     */
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new CheckoutCounterScreenHandler(
                ModScreenHandlers.CHECKOUT_COUNTER_SCREEN_HANDLER,
                syncId, playerInventory, this);
    }

    /**
     * Returns the display name shown in the screen title.
     *
     * @return the translatable display name for the checkout counter
     */
    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471("container.blockmark.checkout_counter");
    }

    @Override
    public boolean method_5442() {
        return inventory.stream().allMatch(class_1799::method_7960);
    }

    @Override
    public class_1799 method_5438(int slot) {
        return inventory.get(slot);
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        class_1799 result = class_1262.method_5430(inventory, slot, amount);
        if (!result.method_7960()) method_5431();
        return result;
    }

    @Override
    public class_1799 method_5441(int slot) {
        class_1799 result = class_1262.method_5428(inventory, slot);
        if (!result.method_7960()) method_5431();
        return result;
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        inventory.set(slot, stack);
        if (stack.method_7947() > method_5444()) {
            stack.method_7939(method_5444());
        }
        method_5431();
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return field_11867.method_19769(player.method_19538(), 8.0);
    }

    @Override
    public void method_5448() {
        inventory.clear();
        method_5431();
    }

    @Override
    public int method_5439() {
        return 27;
    }

    /**
     * Reads block entity data from NBT, including inventory contents.
     *
     * @param nbt the NBT compound to read from
     */
    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        class_1262.method_5429(nbt, inventory);
    }

    /**
     * Writes block entity data to NBT, including inventory contents.
     *
     * @param nbt the NBT compound to write to
     */
    @Override
    protected void method_11007(class_2487 nbt) {
        super.method_11007(nbt);
        class_1262.method_5426(nbt, inventory);
    }

    /**
     * Creates the update packet for synchronizing block entity data
     * to players tracking this chunk.
     *
     * @return a block entity update packet with full NBT data
     */
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    /**
     * Creates the initial chunk data NBT for chunk synchronization.
     * Delegates to createNbt() which includes inventory contents.
     *
     * @return the full NBT compound for initial chunk sync
     */
    @Override
    public class_2487 method_16887() {
        return method_38244();
    }
}
