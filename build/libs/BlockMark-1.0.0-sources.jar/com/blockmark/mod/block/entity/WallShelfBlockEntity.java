package com.blockmark.mod.block.entity;

import com.blockmark.mod.registry.ModBlockEntities;
import com.blockmark.mod.registry.ModScreenHandlers;
import com.blockmark.mod.screen.WallShelfScreenHandler;
import net.minecraft.class_1262;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3908;
import net.minecraft.class_3917;

/**
 * Block entity shared by all shelf, cooler, display, and vending machine blocks.
 * <p>
 * Manages a 27-slot inventory and dynamically selects the correct screen handler
 * type based on the parent block's translation key. Supports standard NBT-based
 * inventory persistence, comparator output for redstone, and full chunk data
 * synchronization for networked clients.
 * </p>
 */
public class WallShelfBlockEntity extends class_2586 implements class_3908, net.minecraft.class_1263 {
    private final class_2371<class_1799> inventory = class_2371.method_10213(27, class_1799.field_8037);

    public WallShelfBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.WALL_SHELF_ENTITY, pos, state);
    }

    private class_3917<?> getScreenHandlerType() {
        class_2248 block = this.method_11010().method_26204();
        String name = block.method_9539();
        if (name.contains("wall_mount_shelf")) return ModScreenHandlers.WALL_MOUNT_SHELF_SCREEN_HANDLER;
        if (name.contains("produce_display")) return ModScreenHandlers.PRODUCE_DISPLAY_SCREEN_HANDLER;
        if (name.contains("glass_cabinet")) return ModScreenHandlers.GLASS_CABINET_SCREEN_HANDLER;
        if (name.contains("open_cooler")) return ModScreenHandlers.OPEN_COOLER_SCREEN_HANDLER;
        if (name.contains("storage_crate")) return ModScreenHandlers.STORAGE_CRATE_SCREEN_HANDLER;
        if (name.contains("vending_machine")) return ModScreenHandlers.VENDING_MACHINE_SCREEN_HANDLER;
        if (name.contains("double_sided_shelf")) return ModScreenHandlers.DOUBLE_SIDED_SHELF_SCREEN_HANDLER;
        if (name.contains("end_cap_shelf")) return ModScreenHandlers.END_CAP_SHELF_SCREEN_HANDLER;
        if (name.contains("heavy_duty_shelf")) return ModScreenHandlers.HEAVY_DUTY_SHELF_SCREEN_HANDLER;
        if (name.contains("beverage_cooler")) return ModScreenHandlers.BEVERAGE_COOLER_SCREEN_HANDLER;
        if (name.contains("freezer_chest")) return ModScreenHandlers.FREEZER_CHEST_SCREEN_HANDLER;
        if (name.contains("fridge")) return ModScreenHandlers.FRIDGE_SCREEN_HANDLER;
        return ModScreenHandlers.WALL_SHELF_SCREEN_HANDLER;
    }

    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new WallShelfScreenHandler(getScreenHandlerType(), syncId, playerInventory, this);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471("container.blockmark.wall_shelf");
    }

    @Override
    public boolean method_5442() { return inventory.stream().allMatch(class_1799::method_7960); }

    @Override
    public class_1799 method_5438(int slot) { return inventory.get(slot); }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        class_1799 result = class_1262.method_5430(inventory, slot, amount);
        if (!result.method_7960()) method_5431();
        return result;
    }

    @Override
    public class_1799 method_5441(int slot) {
        class_1799 result = class_1262.method_5428(inventory, slot);
        if (!result.method_7960()) method_5431();
        return result;
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        inventory.set(slot, stack);
        if (stack.method_7947() > method_5444()) stack.method_7939(method_5444());
        method_5431();
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return field_11867.method_19769(player.method_19538(), 8.0);
    }

    @Override
    public void method_5448() { inventory.clear(); method_5431(); }

    @Override
    public int method_5439() { return 27; }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        class_1262.method_5429(nbt, inventory);
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        super.method_11007(nbt);
        class_1262.method_5426(nbt, inventory);
    }

    /**
     * Creates the update packet for block entity data synchronization
     * to players tracking this chunk.
     *
     * @return a BlockEntityUpdateS2CPacket with full NBT data
     */
    @Override
    public net.minecraft.class_2596<net.minecraft.class_2602> method_38235() {
        return net.minecraft.class_2622.method_38585(this);
    }

    /**
     * Provides the initial chunk data NBT for new chunk loads.
     * Delegates to {@link #method_38244()} for the full serialized state.
     *
     * @return the full NBT compound for initial chunk sync
     */
    @Override
    public class_2487 method_16887() {
        return method_38244();
    }
}

