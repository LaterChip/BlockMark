package com.blockmark.mod.block;

import com.blockmark.mod.block.entity.WallShelfBlockEntity;
import net.minecraft.block.*;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import com.mojang.serialization.MapCodec;

/**
 * Produce Display
 * <p>
 * This block provides a storage inventory accessible via right-click interaction.
 * It supports horizontal facing for placement orientation, waterlogging for
 * submerged placement, custom collision and outline shapes, and automatic
 * inventory item scattering when the block is destroyed.
 * </p>
 *
 * <ul>
 *   <li><b>Facing:</b> Determined by player placement direction (opposite)</li>
 *   <li><b>Waterlogging:</b> Supported via WATERLOGGED property</li>
 *   <li><b>Render Type:</b> MODEL</li>
 *   <li><b>Inventory:</b> 18 slots, dropped on removal</li>
 * </ul>
 *
 * @see WallShelfBlockEntity
 */
public class ProduceDisplayBlock extends class_2237 {
    /** The direction this block faces horizontally. */
    public static final class_2753 FACING = class_2741.field_12481;

    /** Whether this block is waterlogged. */
    public static final class_2746 WATERLOGGED = class_2741.field_12508;

    /** The collision and outline bounding shape for this block (full cube). */
    private static final class_265 SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0);

    /**
     * Constructs a new ProduceDisplayBlock with the given settings.
     * Default state: facing NORTH, not waterlogged.
     *
     * @param settings the block settings (material, hardness, etc.)
     */
    public ProduceDisplayBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664()
                .method_11657(FACING, class_2350.field_11043)
                .method_11657(WATERLOGGED, false));
    }

    /**
     * Creates the block entity for this block.
     * All shelf and display blocks share the WallShelfBlockEntity.
     *
     * @param pos   the position of the block
     * @param state the current block state
     * @return a new WallShelfBlockEntity instance
     */
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new WallShelfBlockEntity(pos, state);
    }

    /**
     * Returns the render type for this block.
     *
     * @param state the current block state (unused)
     * @return MODEL for JSON model rendering
     */
    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    /**
     * Handles right-click interaction. Opens the block's screen handler
     * on the server side for inventory access.
     *
     * @param state  the current block state
     * @param world  the world instance
     * @param pos    the position of the block
     * @param player the player who interacted
     * @param hand   the hand used for interaction
     * @param hit    the hit result details
     * @return SUCCESS on both client and server
     */
    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos,
                               class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236) {
            class_3908 factory = state.method_26196(world, pos);
            if (factory != null) {
                player.method_17355(factory);
            }
        }
        return class_1269.field_5812;
    }

    /**
     * Called when the block state is replaced. Scatters inventory contents
     * if the block type changes (e.g., destroyed).
     *
     * @param state    the old block state
     * @param world    the world instance
     * @param pos      the position of the block
     * @param newState the new block state replacing this one
     * @param moved    whether the block was moved by a piston
     */
    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos,
                                class_2680 newState, boolean moved) {
        if (state.method_26204() != newState.method_26204()) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof class_1263) {
                class_1264.method_5451(world, pos, (class_1263) be);
            }
            super.method_9536(state, world, pos, newState, moved);
        }
    }

    /**
     * Determines the block state when placed, based on the placement context.
     * The block faces opposite to the player's horizontal facing direction.
     *
     * @param ctx the item placement context
     * @return the block state with appropriate facing and waterlogging
     */
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_3610 fluidState = ctx.method_8045().method_8316(ctx.method_8037());
        return this.method_9564()
                .method_11657(FACING, ctx.method_8042().method_10153())
                .method_11657(WATERLOGGED, fluidState.method_15772() == class_3612.field_15910);
    }

    /**
     * Returns the fluid state for this block. If waterlogged, the block
     * contains water at its position.
     *
     * @param state the current block state
     * @return the fluid state (water if waterlogged, empty otherwise)
     */
    @Override
    public class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    /**
     * Updates the block state when a neighboring block changes.
     * Handles waterlogging fluid updates.
     *
     * @param state         the current block state
     * @param direction     the direction of the neighbor update
     * @param neighborState the neighbor's block state
     * @param world         the world access instance
     * @param pos           the position of this block
     * @param neighborPos   the position of the neighbor that changed
     * @return the updated block state
     */
    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction,
                                                 class_2680 neighborState, class_1936 world,
                                                 class_2338 pos, class_2338 neighborPos) {
        if (state.method_11654(WATERLOGGED)) {
            world.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
        }
        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    /**
     * Returns the visual outline shape for rendering selection boxes.
     *
     * @param state   the current block state
     * @param world   the block view
     * @param pos     the position
     * @param context the shape context
     * @return a full-cube VoxelShape
     */
    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    /**
     * Returns the collision shape used for entity physics.
     *
     * @param state   the current block state
     * @param world   the block view
     * @param pos     the position
     * @param context the shape context
     * @return a full-cube VoxelShape
     */
    @Override
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    /**
     * Appends block state properties to the state manager builder.
     * Subclasses should call super.appendProperties first.
     *
     * @param builder the state manager builder
     */
    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, WATERLOGGED);
    }

    /**
     * Returns the MapCodec for serialization.
     *
     * @return the codec for this block type
     */
    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return method_54094(ProduceDisplayBlock::new);
    }
}
