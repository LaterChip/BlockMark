package com.blockmark.mod.block;

import net.minecraft.block.*;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import com.mojang.serialization.MapCodec;

/**
 * Price Tag - a small text display stand block for labeling
 * shelves and products.
 * <p>
 * This block is purely decorative and does not have a block entity
 * or inventory. It supports horizontal facing placement, waterlogging,
 * and a compact 8x8x8 collision/outline shape for realistic rendering.
 * </p>
 *
 * <ul>
 *   <li><b>Facing:</b> Determined by player placement direction (opposite)</li>
 *   <li><b>Waterlogging:</b> Supported via WATERLOGGED property</li>
 *   <li><b>Render Type:</b> MODEL</li>
 *   <li><b>Shape:</b> Compact 8x8x8 cube (centered)</li>
 * </ul>
 */
public class PriceTagBlock extends class_2248 {
    /** The direction this block faces horizontally. */
    public static final class_2753 FACING = class_2741.field_12481;

    /** Whether this block is waterlogged. */
    public static final class_2746 WATERLOGGED = class_2741.field_12508;

    /** Compact collision/outline shape: 4,0,4 to 12,8,12 (centered 8x8x8). */
    private static final class_265 SHAPE = class_2248.method_9541(4.0, 0.0, 4.0, 12.0, 8.0, 12.0);

    /**
     * Constructs a new PriceTagBlock with the given settings.
     * Default state: facing NORTH, not waterlogged.
     *
     * @param settings the block settings (material, hardness, etc.)
     */
    public PriceTagBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664()
                .method_11657(FACING, class_2350.field_11043)
                .method_11657(WATERLOGGED, false));
    }

    /**
     * Returns the render type for this block.
     *
     * @param state the current block state (unused)
     * @return MODEL for JSON model rendering
     */
    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    /**
     * Determines the block state when placed, based on the placement context.
     * The block faces opposite to the player so it appears to face outward.
     *
     * @param ctx the item placement context
     * @return the block state with appropriate facing and waterlogging
     */
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_3610 fluidState = ctx.method_8045().method_8316(ctx.method_8037());
        return this.method_9564()
                .method_11657(FACING, ctx.method_8042().method_10153())
                .method_11657(WATERLOGGED, fluidState.method_15772() == class_3612.field_15910);
    }

    /**
     * Returns the fluid state for this block. If waterlogged, the block
     * contains water at its position.
     *
     * @param state the current block state
     * @return the fluid state (water if waterlogged, empty otherwise)
     */
    @Override
    public class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    /**
     * Updates the block state when a neighboring block changes.
     * Handles waterlogging fluid updates.
     *
     * @param state         the current block state
     * @param direction     the direction of the neighbor update
     * @param neighborState the neighbor's block state
     * @param world         the world access instance
     * @param pos           the position of this block
     * @param neighborPos   the position of the neighbor that changed
     * @return the updated block state
     */
    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction,
                                                 class_2680 neighborState, class_1936 world,
                                                 class_2338 pos, class_2338 neighborPos) {
        if (state.method_11654(WATERLOGGED)) {
            world.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
        }
        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    /**
     * Returns the visual outline shape for rendering selection boxes.
     * Uses a compact 8x8x8 bounding box to match the small size of a price tag stand.
     *
     * @param state   the current block state
     * @param world   the block view
     * @param pos     the position
     * @param context the shape context
     * @return a compact VoxelShape (4,0,4 to 12,8,12)
     */
    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    /**
     * Returns the collision shape used for entity physics.
     * Uses the same compact 8x8x8 bounding box as the outline shape.
     *
     * @param state   the current block state
     * @param world   the block view
     * @param pos     the position
     * @param context the shape context
     * @return a compact VoxelShape (4,0,4 to 12,8,12)
     */
    @Override
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    /**
     * Appends block state properties to the state manager builder.
     * Includes facing and waterlogging.
     *
     * @param builder the state manager builder
     */
    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, WATERLOGGED);
    }

    /**
     * Returns the MapCodec for serialization.
     *
     * @return the codec for this block type
     */
    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return method_54094(PriceTagBlock::new);
    }
}
